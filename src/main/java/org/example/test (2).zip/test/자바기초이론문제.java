package org.example.test;

public class 자바기초이론문제 {
}

/*

Q 01. D
Q 02. A
Q 03. D
Q 04. B
Q 05. C
Q 06. C
Q 07. A
Q 08. D
Q 09. D
-------
Q 10
Q 11. 3
Q 12. Animal의 추상메서드 sound를 Dog에서 오버라이딩하지 않아서


 */